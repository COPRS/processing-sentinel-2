# ipf L0 + L1 + Inventory with jdk17 installed

Docker image name expected : csc/s2pdgs/s2ipf_l0_l1_jdk17:4.4.4
